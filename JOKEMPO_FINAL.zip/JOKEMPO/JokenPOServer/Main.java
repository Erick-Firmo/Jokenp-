import domain.model.Player;
import domain.usecase.MultiplayerUC;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.LinkedList;
import java.util.Queue;

public class Main {
    public static final boolean RUNNING = true;
    public static final int SERVER_PORT = 6666;

    public static void main(String[] args) {
        try(ServerSocket server = new ServerSocket(SERVER_PORT)) {
            while (RUNNING) {
                final Socket playerSession = server.accept();
                final DataInputStream dis = new DataInputStream(playerSession.getInputStream());
                final String name = dis.readUTF();

                final Player player = new Player(name, 0, 0, playerSession);

                MultiplayerUC.addPlayer(player);

                System.out.println(name.concat(" - entrou no servidor"));
            }
        }catch(Exception e){System.out.println(e);}
    }
}
