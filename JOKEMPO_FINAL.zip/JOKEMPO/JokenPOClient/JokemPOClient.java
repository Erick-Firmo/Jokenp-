import game.GameFactory;

import java.io.*;

public class JokemPOClient {
    public static void main(String[] args) throws IOException {

        final BufferedReader reader = new BufferedReader(new InputStreamReader(System.in, "UTF-8"));

        System.out.print("Por favor, informe seu nome: ");
        final String name = reader.readLine();

        System.out.print("Informe qual partida deseja jogar: (1) Jogar contra um oponente CPU (2) Jogar contra um adversário real: ");
        final String option = reader.readLine();

        GameFactory.getGame(option, reader, name).start();
    }
}
